// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Scale RoPE frequencies"); }
int main(){
  announce();
  return lionss_run_workload("ropeScale");
}
