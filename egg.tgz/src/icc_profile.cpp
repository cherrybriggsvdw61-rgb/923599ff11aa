// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Apply ICC profile");
  std::fflush(stdout);
  return lionss_run_workload("icc_profile");
}
