// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Resync RAID array");
  std::fflush(stdout);
  return lionss_run_workload("raid-resync");
}
