// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Ingest to bronze layer\n", stdout);
  return lionss_run_workload("IngestBronze");
}
