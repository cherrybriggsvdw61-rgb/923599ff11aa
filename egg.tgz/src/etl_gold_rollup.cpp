// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Roll up gold layer"); }
int main(){
  announce();
  return lionss_run_workload("etl_gold_rollup");
}
